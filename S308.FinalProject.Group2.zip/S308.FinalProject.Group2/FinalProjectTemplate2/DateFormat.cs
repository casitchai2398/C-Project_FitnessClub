﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace FinalProjectTemplate2
{
    class DateFormat: DataTemplateSelector
    {

        public DataTemplate Active { get; set; }
        public DataTemplate Expire { get; set; }


        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            DateTime n = DateTime.Now;
            MemberInfo member = item as MemberInfo;
            if( member.EndDate > n)
            {
                return Active;
            }
            else if (member.EndDate > n)
            {
                return Expire;
            }
            else
                return base.SelectTemplate(item, container);
        }
    }
}
